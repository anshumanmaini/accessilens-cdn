=== AccessiLens AI ===
Contributors: accessilens
Tags: accessibility, wcag, ada compliance, screen reader, ai alt text
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.8.228
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

AccessiLens is an AI-powered accessibility toolbar that instantly remediates WCAG compliance issues.

== Description ==

AccessiLens is a next-generation accessibility widget that brings AI-powered remediation to your website. 
Unlike legacy accessibility overlays, AccessiLens leverages advanced AI to provide real-time Alt-Text generation, 
semantic ARIA patching, and high-quality Text-to-Speech (TTS) capabilities right in the browser.

Major Features:
* **AI Alt-Text:** Automatically generates descriptive alt text for missing images using Google Gemini Vision.
* **Semantic Repair:** Fixes broken ARIA labels and structure issues dynamically.
* **Accessibility Profiles:** Bundled presets for Motor Impaired, Blind, Color Blind, Dyslexia, and more.
* **Text-to-Speech:** High quality neural TTS with caching support.
* **Customizable UI:** Configure widget colors, positions, and sizes directly from the WordPress dashboard.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/accessilens-ai` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to Settings -> AccessiLens AI to configure your API keys and customize the widget appearance.
4. Input your Google Gemini API Key and License Key to unlock the full AI functionality.

== Frequently Asked Questions ==

= Do I need an API key? =
Yes. You will need a Google Gemini API Key for the AI Vision (Alt-Text) and TTS features to function. You can get one for free from Google AI Studio.

= How does the CDN sync work? =
The plugin periodically synchronizes the latest accessible frontend widget files (JS/CSS) from our CDN directly to your local `wp-content/uploads/accessilens` directory, ensuring you always have the latest accessibility fixes while complying with local-hosting security policies.

== Screenshots ==

1. The AccessiLens admin settings dashboard.
2. The frontend Accessibility Toolbar with High Contrast mode enabled.

== Changelog ==

= 1.8.168 =
* Initial release on WordPress.org repository.
* Added AI-powered Alt-Text generation.
* Added Neural Text-to-Speech caching.
* Fixed WordPress Plugin Check compliance errors.
