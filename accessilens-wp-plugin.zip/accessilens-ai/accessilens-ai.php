<?php
/**
 * Plugin Name:       AccessiLens AI
 * Description:       An AI-powered, embeddable accessibility tool to assist users and ensure website compliance.
 * Version:           1.8.256
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            AccessiLens AI Team
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       accessilens-ai
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// 0. Admin Notices for pending configuration
function accessilens_ai_admin_notices()
{
    // Only show for admins
    if (!current_user_can('manage_options')) {
        return;
    }

    $screen = get_current_screen();
    // Don't show on our own settings page as we already have local notices there
    if ($screen && $screen->id === 'settings_page_accessilens-ai-settings') {
        return;
    }

    $api_key = get_option('accessilens_ai_api_key', '');
    $license_key = get_option('accessilens_license_key', '');
    
    $pending = [];
    if (empty($api_key)) $pending[] = 'Google Gemini API Key';
    if (empty($license_key)) $pending[] = 'AccessiLens License Key';

    if (!empty($pending)) {
        $settings_url = admin_url('options-general.php?page=accessilens-ai-settings');
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>AccessiLens AI:</strong> Configuration pending. Please add your 
                <?php echo wp_kses_post(implode(' and ', array_map(function($item) { return "<strong>" . esc_html($item) . "</strong>"; }, $pending))); ?> 
                in the <a href="<?php echo esc_url($settings_url); ?>">settings page</a> to activate AI features and usage tracking.
            </p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'accessilens_ai_admin_notices');

// 1. Create admin page
function accessilens_ai_create_admin_page()
{
    add_options_page(
        'AccessiLens AI Settings',
        'AccessiLens AI',
        'manage_options',
        'accessilens-ai-settings',
        'accessilens_ai_settings_page_content'
    );
}
add_action('admin_menu', 'accessilens_ai_create_admin_page');

// 1b. Add "Settings" link on the Plugins list page
function accessilens_ai_plugin_action_links($links)
{
    $settings_link = '<a href="' . admin_url('options-general.php?page=accessilens-ai-settings') . '">' . __('Settings', 'accessilens-ai') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'accessilens_ai_plugin_action_links');

// 1c. Enqueue admin stylesheet and scripts (WordPress.org compliant)
function accessilens_ai_admin_enqueue_scripts($hook)
{
    if ('settings_page_accessilens-ai-settings' !== $hook) {
        return;
    }
    wp_enqueue_style(
        'accessilens-ai-admin-style',
        plugin_dir_url(__FILE__) . 'css/admin.css',
        [],
        '1.8.256'
    );
    wp_enqueue_script(
        'accessilens-ai-admin-script',
        plugin_dir_url(__FILE__) . 'js/admin.js',
        [],
        '1.8.256',
        true
    );
}
add_action('admin_enqueue_scripts', 'accessilens_ai_admin_enqueue_scripts');

// 2. Handle settings page display and saving
function accessilens_ai_settings_page_content()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['accessilens_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['accessilens_nonce'])), 'accessilens_save_settings')) {
        $api_key = isset($_POST['accessilens_ai_api_key']) ? sanitize_text_field(wp_unslash($_POST['accessilens_ai_api_key'])) : '';
        $license_key = isset($_POST['accessilens_license_key']) ? sanitize_text_field(wp_unslash($_POST['accessilens_license_key'])) : '';
        
        update_option('accessilens_ai_api_key', $api_key);
        update_option('accessilens_license_key', $license_key);

            // Save New Widget Customizer Settings
            $color = sanitize_hex_color(wp_unslash($_POST['accessilens_icon_color'] ?? '#2563eb'));
            $position = sanitize_text_field(wp_unslash($_POST['accessilens_icon_position'] ?? 'bottom-right'));
            $iconType = sanitize_text_field(wp_unslash($_POST['accessilens_icon_type'] ?? 'person'));
            $iconShape = sanitize_text_field(wp_unslash($_POST['accessilens_icon_shape'] ?? 'round'));
            $widgetSize = sanitize_text_field(wp_unslash($_POST['accessilens_widget_size'] ?? 'normal'));
            $ttsVoice = sanitize_text_field(wp_unslash($_POST['accessilens_tts_voice'] ?? ''));

            update_option('accessilens_icon_color', $color);
            update_option('accessilens_icon_position', $position);
            update_option('accessilens_icon_type', $iconType);
            update_option('accessilens_icon_shape', $iconShape);
            update_option('accessilens_widget_size', $widgetSize);
            update_option('accessilens_tts_voice', $ttsVoice);
            
            $toolbarLanguage = sanitize_text_field(wp_unslash($_POST['accessilens_toolbar_language'] ?? 'en'));
            update_option('accessilens_toolbar_language', $toolbarLanguage);

            // SYNC TO CLOUD RUN BACKEND (Only if user explicitly provided a license key)
            if (!empty($license_key)) {
                $current_domain = str_replace(['https://', 'http://'], '', get_site_url());
                $update_url = "https://accessilens-ai.com/api/widget/update?domain=" . urlencode($current_domain) . "&clientId=" . urlencode($license_key);
                
                wp_remote_post($update_url, [
                    'method' => 'POST',
                    'headers' => ['Content-Type' => 'application/json'],
                    'body' => json_encode([
                        'color' => $color,
                        'position' => $position,
                        'iconType' => $iconType,
                        'iconShape' => $iconShape
                    ]),
                    'timeout' => 15,
                    'blocking' => true 
                ]);
            }

        // Purge popular caches to ensure settings apply immediately
        if (function_exists('wp_cache_clear_cache')) {
            wp_cache_clear_cache();
        } // WP Super Cache
        if (function_exists('w3tc_flush_all')) {
            w3tc_flush_all();
        } // W3 Total Cache
        if (function_exists('rocket_clean_domain')) {
            rocket_clean_domain();
        } // WP Rocket
        if (class_exists('LiteSpeed_Cache_API') && method_exists('LiteSpeed_Cache_API', 'purge_all')) {
            LiteSpeed_Cache_API::purge_all();
        } // LiteSpeed
        if (class_exists('autoptimizeCache') && method_exists('autoptimizeCache', 'clearall')) {
            autoptimizeCache::clearall();
        } // Autoptimize

        if (empty($api_key) || empty($license_key)) {
            echo '<div class="notice notice-info is-dismissible"><p>Settings saved. Add your License Key and Gemini API Key to activate AI features (Alt-Text & Vision AI).</p></div>';
        } else {
            echo '<div class="notice notice-success is-dismissible"><p>Settings saved and website cache purged successfully.</p></div>';
        }
    }

    $saved_api_key = get_option('accessilens_ai_api_key', '');
    $saved_license_key = get_option('accessilens_license_key', '');

    $current_domain = str_replace(['https://', 'http://'], '', get_site_url());
    $is_domain_verified = false;

    if (!empty($saved_license_key)) {
        $verify_url = "https://accessilens-ai.com/api/widget/verify?domain=" . urlencode($current_domain) . "&clientId=" . urlencode($saved_license_key) . "&nocache=1";
        $verify_response = wp_remote_get($verify_url);
        if (!is_wp_error($verify_response)) {
            $verify_data = json_decode(wp_remote_retrieve_body($verify_response), true);
            $is_domain_verified = $verify_data['valid'] ?? false;
        }
    }

    $is_licensed = $is_domain_verified;
    ?>
    <div class="wrap">
        <h1 style="display:inline-block; margin-right:12px;"><?php echo esc_html(get_admin_page_title()); ?></h1>
        <span style="background:#e2e8f0; color:#475569; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:bold; vertical-align:middle; position:relative; top:-2px;">v1.8.256</span>
        <form method="POST" action="">
            <?php wp_nonce_field('accessilens_save_settings', 'accessilens_nonce'); ?>

            <h2>AccessiLens License Key</h2>
            <p>
                Get your free license key at
                <a href="https://accessilens-ai.com/portal"
                    target="_blank"><strong>AccessiLens Portal</strong></a>.
                Paste it below to activate tracking and unlock your plan's call limit.
            </p>
            <?php if (!empty($saved_license_key) && $is_domain_verified): ?>
                <div style="background:#f0fdf4;border:1px solid #86efac;padding:10px 14px;border-radius:6px;margin-bottom:12px;color:#166534;">
                    ✅ <strong>License active</strong> — your usage is being tracked in the AccessiLens dashboard.
                </div>
            <?php elseif (!empty($saved_license_key) && !$is_domain_verified): ?>
                <div style="background:#fef2f2;border:1px solid #fecaca;padding:10px 14px;border-radius:6px;margin-bottom:12px;color:#991b1b;">
                    ⚠️ <strong>Domain Unauthorized</strong> — your license key is valid, but this domain is not whitelisted in your AccessiLens Portal. The widget is disabled.
                </div>
            <?php else: ?>
                <div style="background:#fefce8;border:1px solid #fde047;padding:10px 14px;border-radius:6px;margin-bottom:12px;color:#854d0e;">
                    ⚠️ No license key — the plugin is currently <strong>disabled</strong> on your website. Add a key to activate the widget.
                </div>
            <?php endif; ?>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row"><label for="accessilens_license_key">License Key</label></th>
                        <td>
                            <input name="accessilens_license_key" type="text" id="accessilens_license_key"
                                value="<?php echo esc_attr($saved_license_key); ?>" class="regular-text"
                                placeholder="al_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                            <p class="description">Your unique AccessiLens license key. Check your <a href="https://accessilens-ai.com/portal" target="_blank">AccessiLens Portal</a> for your current AI call limits.</p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <h2>Google Gemini API Key</h2>
            <p>Enter your API key below. You can obtain a key from the <a href="https://ai.google.dev/"
                    target="_blank">Google AI Studio</a>. This key is stored securely on your server and is never exposed to
                website visitors.</p>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row"><label for="accessilens_ai_api_key">Gemini API Key</label></th>
                        <td><input name="accessilens_ai_api_key" type="password" id="accessilens_ai_api_key"
                                value="<?php echo esc_attr($saved_api_key); ?>" class="regular-text"
                                placeholder="Enter your Gemini API key"></td>
                    </tr>
                </tbody>
            </table>

            <hr>

            <div class="al-card">
                <h2 class="al-section-title">🎨 Widget Customization</h2>
                <p class="al-section-desc">Configure how AccessiLens looks and behaves on your website. All customization is managed here in your plugin.</p>
                
                <?php
                // Domain verification is now performed at the top of the function
                ?>

                <div style="background:<?php echo $is_domain_verified ? '#f0fdf4' : '#fef2f2'; ?>; border: 1px solid <?php echo $is_domain_verified ? '#86efac' : '#fecaca'; ?>; padding: 16px; border-radius: 10px; margin-bottom: 24px;">
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <div>
                            <span class="al-badge" style="background:<?php echo $is_domain_verified ? '#dcfce7' : '#fee2e2'; ?>; color:<?php echo $is_domain_verified ? '#166534' : '#991b1b'; ?>;">
                                <?php echo $is_domain_verified ? '🛡️ Domain Active' : '⚠️ Unauthorized'; ?>
                            </span>
                            <p style="margin:8px 0 0 0; font-size:13px; font-weight:500; color:<?php echo $is_domain_verified ? '#166534' : '#991b1b'; ?>;">
                                <?php if ($is_domain_verified): ?>
                                    Domain <strong><?php echo esc_html($current_domain); ?></strong> is verified.
                                <?php else: ?>
                                    Domain <strong><?php echo esc_html($current_domain); ?></strong> is not whitelisted. The widget will <strong>not appear</strong> on your website until you add this domain in your <a href="https://accessilens-ai.com/portal/account" target="_blank" style="color:inherit; font-weight:700; text-decoration:underline;">AccessiLens Portal → Domain Firewall</a>.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>

                <?php
                $color = esc_attr(get_option('accessilens_icon_color', '#2563eb'));
                $pos = get_option('accessilens_icon_position', 'bottom-right');
                $type = get_option('accessilens_icon_type', 'person');
                $shape = get_option('accessilens_icon_shape', 'round');
                $widgetSize = get_option('accessilens_widget_size', 'normal');
                $ttsVoice = get_option('accessilens_tts_voice', '');
                $toolbarLanguage = get_option('accessilens_toolbar_language', 'en');
                ?>



                <div class="al-customizer-grid">
                    <!-- LEFT: Controls -->
                    <div>
                        <!-- Primary Brand Color -->
                        <div style="margin-bottom: 20px;">
                            <label class="al-field-label" for="accessilens_icon_color">Primary Brand Color</label>
                            <div class="al-color-row">
                                <input aria-label="Primary Brand Color Picker" name="accessilens_icon_color" type="color" id="accessilens_icon_color" value="<?php echo esc_attr($color); ?>" class="al-color-picker">
                                <input aria-label="Primary Brand Color Hex Code" type="text" id="accessilens_color_hex" value="<?php echo esc_attr($color); ?>" class="al-color-hex" maxlength="7" pattern="#[0-9a-fA-F]{6}">
                            </div>
                        </div>

                        <!-- Position + Shape Row -->
                        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:20px;">
                            <div>
                                <label class="al-field-label">Float Position</label>
                                <select name="accessilens_icon_position" id="accessilens_icon_position" class="al-select">
                                    <option value="bottom-right" <?php selected($pos, 'bottom-right'); ?>>Bottom Right</option>
                                    <option value="bottom-left" <?php selected($pos, 'bottom-left'); ?>>Bottom Left</option>
                                    <option value="top-right" <?php selected($pos, 'top-right'); ?>>Top Right</option>
                                    <option value="top-left" <?php selected($pos, 'top-left'); ?>>Top Left</option>
                                    <option value="middle-left" <?php selected($pos, 'middle-left'); ?>>Middle Left</option>
                                    <option value="middle-right" <?php selected($pos, 'middle-right'); ?>>Middle Right</option>
                                </select>
                            </div>
                            <div>
                                <label class="al-field-label">Button Shape</label>
                                <select name="accessilens_icon_shape" id="accessilens_icon_shape" class="al-select">
                                    <option value="round" <?php selected($shape, 'round'); ?>>Circle (Round)</option>
                                    <option value="rounded" <?php selected($shape, 'rounded'); ?>>Squircle</option>
                                    <option value="square" <?php selected($shape, 'square'); ?>>Square</option>
                                </select>
                            </div>
                            <div>
                                <label class="al-field-label">Widget Size</label>
                                <select name="accessilens_widget_size" id="accessilens_widget_size" class="al-select">
                                    <option value="normal" <?php selected($widgetSize, 'normal'); ?>>Normal</option>
                                    <option value="large" <?php selected($widgetSize, 'large'); ?>>Large</option>
                                </select>
                            </div>
                        </div>

                        <!-- Voice Selection Row -->
                        <div style="margin-bottom:20px;">
                            <label class="al-field-label">Read Aloud Voice</label>
                            <div style="display:flex; gap:10px; align-items:center;">
                                <select name="accessilens_tts_voice" id="accessilens_tts_voice" class="al-select" style="flex:1;">
                                    <option value="" <?php selected($ttsVoice, ''); ?>>System Default</option>
                                    <option value="Female" <?php selected($ttsVoice, 'Female'); ?>>Default Female</option>
                                    <option value="Male" <?php selected($ttsVoice, 'Male'); ?>>Default Male</option>
                                    <option value="US Female" <?php selected($ttsVoice, 'US Female'); ?>>US English (Female)</option>
                                    <option value="US Male" <?php selected($ttsVoice, 'US Male'); ?>>US English (Male)</option>
                                    <option value="UK Female" <?php selected($ttsVoice, 'UK Female'); ?>>UK English (Female)</option>
                                    <option value="UK Male" <?php selected($ttsVoice, 'UK Male'); ?>>UK English (Male)</option>
                                    <option value="AU Female" <?php selected($ttsVoice, 'AU Female'); ?>>Australian English (Female)</option>
                                    <option value="AU Male" <?php selected($ttsVoice, 'AU Male'); ?>>Australian English (Male)</option>
                                </select>
                                <button type="button" id="al-play-voice-btn" class="button" style="display:flex; align-items:center; gap:6px; height: 38px; border-radius: 8px;">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Preview
                                </button>
                            </div>
                            <p class="description" style="margin-top: 8px;">Select a voice profile. AccessiLens will synthesize this using ultra-premium Microsoft Edge Neural Voices ($0.00 cost, natural human inflection, high compatibility on all modern operating systems and mobile browsers).</p>
                        </div>

                        <!-- Toolbar Language Row -->
                        <div style="margin-bottom:20px;">
                            <label class="al-field-label">Widget UI Language</label>
                            <select name="accessilens_toolbar_language" id="accessilens_toolbar_language" class="al-select">
                                <option value="en" <?php selected($toolbarLanguage, 'en'); ?>>English</option>
                                <option value="es" <?php selected($toolbarLanguage, 'es'); ?>>Spanish</option>
                                <option value="fr" <?php selected($toolbarLanguage, 'fr'); ?>>French</option>
                                <option value="de" <?php selected($toolbarLanguage, 'de'); ?>>German</option>
                                <option value="it" <?php selected($toolbarLanguage, 'it'); ?>>Italian</option>
                                <option value="pt" <?php selected($toolbarLanguage, 'pt'); ?>>Portuguese</option>
                                <option value="ar" <?php selected($toolbarLanguage, 'ar'); ?>>Arabic</option>
                            </select>
                            <p class="description" style="margin-top: 8px;">Translates the buttons and menus of the accessibility widget into the selected language.</p>
                        </div>



                        <!-- Widget Icon Grid -->
                        <div style="margin-bottom: 20px;">
                            <label class="al-field-label">Widget Icon</label>
                            <input type="hidden" name="accessilens_icon_type" id="accessilens_icon_type" value="<?php echo esc_attr($type); ?>">
                            <div class="al-icon-grid">
                                <button type="button" class="al-icon-btn <?php echo $type === 'person' ? 'active' : ''; ?>" data-icon="person" title="Person">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg>
                                    <span>Person</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'accessible' ? 'active' : ''; ?>" data-icon="accessible" title="Universal Access">
                                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z"/></svg>
                                    <span>Access</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'wheelchair' ? 'active' : ''; ?>" data-icon="wheelchair" title="Modern Wheelchair">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="4" r="2"/><path d="M10 6v5h5l2.5 6"/><circle cx="8.5" cy="17.5" r="3.5"/><path d="M15 17.5h4"/></svg>
                                    <span>Wheelchair</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'eye' ? 'active' : ''; ?>" data-icon="eye" title="Eye / Vision">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <span>Eye</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'clean' ? 'active' : ''; ?>" data-icon="clean" title="Clean / Sparkles">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
                                    <span>Clean</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- RIGHT: Live Preview -->
                    <div class="al-preview-panel">
                        <span class="al-preview-label">Live Preview</span>
                        <div class="al-preview-viewport" id="al-preview-viewport">
                            <span class="al-preview-hint">This is how the widget will appear on your website.</span>
                            <div class="al-preview-fab" id="al-preview-fab">
                                <!-- Icon injected by JS -->
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// 3. Enqueue scripts and styles on the frontend
function accessilens_ai_enqueue_scripts()
{
    // **STABILITY FIX**: Prevent the widget from loading on admin, login, and registration pages.
    if (is_admin() || in_array($GLOBALS['pagenow'], ['wp-login.php', 'wp-register.php'])) {
        return;
    }

    // Domain verification check if license key is configured
    $license_key = get_option('accessilens_license_key', '');
    $current_domain = str_replace(['https://', 'http://'], '', get_site_url());

    if (!empty($license_key)) {
        $transient_key = 'accessilens_domain_auth_' . md5($current_domain . $license_key);
        $is_verified = get_transient($transient_key);

        if (false === $is_verified) {
            $verify_url = "https://accessilens-ai.com/api/widget/verify?domain=" . urlencode($current_domain) . "&clientId=" . urlencode($license_key);
            $verify_response = wp_remote_get($verify_url);
            
            if (!is_wp_error($verify_response)) {
                $verify_data = json_decode(wp_remote_retrieve_body($verify_response), true);
                $is_verified = (isset($verify_data['valid']) && $verify_data['valid']) ? 'yes' : 'no';
                set_transient($transient_key, $is_verified, HOUR_IN_SECONDS);
            } else {
                // Fail open if the API is temporarily unreachable
                $is_verified = 'yes';
            }
        }

        if ($is_verified === 'no') {
            return; // Domain is blocked in portal firewall
        }
    }

    $script_version = '1.8.256';
    $script_url = plugin_dir_url(__FILE__) . 'accessilens.js?v=' . $script_version;
    wp_enqueue_script('accessilens-ai-script', $script_url, [], $script_version, false);
    
    $style_version = '1.8.256';
    $style_url = plugin_dir_url(__FILE__) . 'accessilens.css?v=' . $style_version;
    wp_enqueue_style('accessilens-ai-style', $style_url, [], $style_version);
    
    // **CORRUPTION FIX**: Explicitly mark the script to be ignored by minifiers (Autoptimize, WP Rocket, etc.)
    add_filter('script_loader_tag', function($tag, $handle) {
        if ('accessilens-ai-script' !== $handle) return $tag;
        // Add data-cfasync="false" for Cloudflare and data-no-minify="1" for WP Rocket
        return str_replace('<script', '<script data-cfasync="false" data-no-optimize="1" data-no-minify="1" data-no-defer="1"', $tag);
    }, 10, 2);

    // Pass configuration to frontend widget.
    // Note: licenseKey acts as the public Client ID for domain firewall verification (safe in HTML).
    // The secret Google Gemini API key is strictly stored server-side and never exposed.
    wp_localize_script(
        'accessilens-ai-script',
        'accessilensData',
        [
            'pluginUrl' => plugin_dir_url(__FILE__),
            'proxyUrl' => rest_url('accessilens-ai/v1/proxy'),
            'nonce' => wp_create_nonce('wp_rest'),
            'licenseKey' => $license_key,
            'iconPosition' => get_option('accessilens_icon_position', 'bottom-right'),
            'iconShape' => get_option('accessilens_icon_shape', 'round'),
            'iconColor' => get_option('accessilens_icon_color', '#2563EB'),
            'iconType' => get_option('accessilens_icon_type', 'person'),
            'widgetSize' => get_option('accessilens_widget_size', 'normal'),
            'ttsVoice' => get_option('accessilens_tts_voice', ''),
            'toolbarLanguage' => get_option('accessilens_toolbar_language', 'en'),
            'logoUrl' => get_option('accessilens_logo_url', ''),
            'defaultMode' => get_option('accessilens_default_mode', 'light'),
        ]
    );
}
add_action('wp_enqueue_scripts', 'accessilens_ai_enqueue_scripts', 999);

// 4. **SECURITY**: Create a secure REST API endpoint to act as a proxy
function accessilens_ai_register_proxy_endpoint()
{
    register_rest_route('accessilens-ai/v1', '/proxy', [
        'methods' => 'POST',
        'callback' => 'accessilens_ai_proxy_handler',
        'permission_callback' => function ($request) {
            // **SECURITY**: Verify the nonce passed in the header.
            return wp_verify_nonce($request->get_header('x_wp_nonce'), 'wp_rest');
        },
    ]);
}
add_action('rest_api_init', 'accessilens_ai_register_proxy_endpoint');

// ─── Error Sanitizer — never expose raw API errors to users ──────────────────
function accessilens_sanitize_api_error(string $raw_message, int $status_code = 0): string
{
    $lower = strtolower($raw_message);

    // Quota / rate-limit errors
    if (false !== strpos($lower, 'quota') || false !== strpos($lower, 'rate') || $status_code === 429) {
        return 'The Google Gemini API Key you provided has reached its usage limit. Please upgrade your Google AI Studio plan to continue using AI features.';
    }
    // Auth / API key errors
    if (false !== strpos($lower, 'api key') || false !== strpos($lower, 'permission') || false !== strpos($lower, 'forbidden') || $status_code === 403) {
        return 'The AI service could not authenticate. Please ask the site administrator to verify the API key in Settings → AccessiLens AI.';
    }
    // Safety / content filtering
    if (false !== strpos($lower, 'safety') || false !== strpos($lower, 'blocked') || false !== strpos($lower, 'harm')) {
        return 'This content could not be processed due to safety guidelines. Please try different content.';
    }
    // Model not found
    if (false !== strpos($lower, 'not found') || false !== strpos($lower, 'model')) {
        return 'The AI model is temporarily unavailable. Please try again in a moment.';
    }
    // Timeout / connection errors
    if (false !== strpos($lower, 'timeout') || false !== strpos($lower, 'timed out') || false !== strpos($lower, 'curl error')) {
        return 'The AI service is temporarily unavailable. Please try again in a few seconds.';
    }
    // Generic fallback — never expose raw message
    return 'Something went wrong with the AI service. Please try again.';
}

// 5. **SECURITY**: Handle the proxy request on the server
function accessilens_ai_proxy_handler(WP_REST_Request $request)
{
    $api_key = get_option('accessilens_ai_api_key');
    if (empty($api_key)) {
        return new WP_REST_Response(['success' => false, 'message' => 'AI features are not available. Please ask the site administrator to configure the Gemini API key in Settings → AccessiLens AI.'], 400);
    }

    // **SECURITY**: Simple Rate Limiting (max 60 requests per minute per IP)
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1';
    $transient_key = 'accessilens_rate_' . md5($ip);
    $request_count = (int) get_transient($transient_key);

    if ($request_count > 60) {
        return new WP_REST_Response(['success' => false, 'message' => 'You\'re using AI features too quickly. Please wait a moment and try again.'], 429);
    }
    set_transient($transient_key, $request_count + 1, MINUTE_IN_SECONDS);

    $params = $request->get_json_params();
    $action = isset($params['action']) ? sanitize_text_field($params['action']) : '';

    // Direct Google Gemini API endpoint is required for multimodal vision (Alt-Text analysis),
    // neural audio synthesis (TTS), and backwards compatibility with WordPress 6.x.
    // Declared in readme.txt under External or Third-Party Services.
    $gemini_api_base = 'https://generativelanguage.googleapis.com/v1beta/models/';
    $request_body = [];
    $model = '';

    if ($action === 'generateContent') {
        $request_body = ['contents' => $params['contents']];

        // **IMAGE LENS FIX**: Process imageUrl server-side to bypass CORS
        if (isset($request_body['contents'][0]['parts'])) {
            foreach ($request_body['contents'][0]['parts'] as $key => $part) {
                if (isset($part['imageUrl'])) {
                    $image_url = $part['imageUrl']; // Don't use esc_url_raw yet because it breaks data URLs
                    
                    if (0 === strpos($image_url, 'data:image/')) {
                        // It's a base64 encoded data URL (like from SVG rasterization)
                        $comma_pos = strpos($image_url, ',');
                        if ($comma_pos !== false) {
                            $header = substr($image_url, 0, $comma_pos);
                            $base64_data = substr($image_url, $comma_pos + 1);
                            
                            // Extract mime type (e.g. data:image/png;base64)
                            preg_match('/^data:(image\/[a-zA-Z0-9\-\+]+);/', $header, $matches);
                            $mime_type = $matches[1] ?? 'image/png';
                            
                            unset($request_body['contents'][0]['parts'][$key]['imageUrl']);
                            $request_body['contents'][0]['parts'][$key]['inlineData'] = [
                                'mimeType' => $mime_type,
                                'data' => $base64_data
                            ];
                            continue;
                        }
                    }

                    // For regular HTTP/HTTPS URLs
                    $image_url = esc_url_raw($image_url);
                    $image_response = wp_remote_get($image_url, ['timeout' => 20]);

                    if (is_wp_error($image_response) || wp_remote_retrieve_response_code($image_response) !== 200) {
                        return new WP_REST_Response(['success' => false, 'message' => 'We couldn\'t load this image for analysis. The image may be protected or unavailable.'], 500);
                    }

                    // **SECURITY**: Prevent massive file downloads (limit to 5MB)
                    $image_size = (int) wp_remote_retrieve_header($image_response, 'content-length');
                    if ($image_size > 5 * 1024 * 1024) {
                        return new WP_REST_Response(['success' => false, 'message' => 'This image is too large to analyze (max 5 MB). Please try a smaller image.'], 400);
                    }

                    $image_data = wp_remote_retrieve_body($image_response);
                    $mime_type = wp_remote_retrieve_header($image_response, 'content-type');

                    // Replace imageUrl part with inlineData part for Gemini
                    unset($request_body['contents'][0]['parts'][$key]['imageUrl']);
                    $request_body['contents'][0]['parts'][$key]['inlineData'] = [
                        'mimeType' => $mime_type ?: 'image/jpeg',
                        'data' => base64_encode($image_data)
                    ];
                }
            }
        }
    } elseif ($action === 'tts') {
        // Robust text sanitization for TTS
        $text_to_speak = isset($params['text']) ? $params['text'] : '';
        $text_to_speak = html_entity_decode($text_to_speak);
        $text_to_speak = wp_strip_all_tags($text_to_speak);
        $text_to_speak = preg_replace('/\s+/', ' ', $text_to_speak);
        $text_to_speak = trim($text_to_speak);

        if (empty($text_to_speak)) {
            return new WP_REST_Response(['success' => false, 'message' => 'No text found on this page to read aloud.'], 400);
        }
        
        $hash = md5($text_to_speak);
        $upload_dir = wp_upload_dir();
        $cache_dir = $upload_dir['basedir'] . '/accessilens/tts';
        $cache_file = $cache_dir . '/' . $hash . '.txt';
        
        if (file_exists($cache_file)) {
            $cached_audio = file_get_contents($cache_file);
            return new WP_REST_Response(['success' => true, 'audioContent' => $cached_audio], 200);
        }
        
        $model = 'gemini-2.5-flash-preview-tts';
        $request_body = [
            'contents' => [['parts' => [['text' => $text_to_speak]]]],
            'generationConfig' => [
                'responseModalities' => ['AUDIO'],
                'speechConfig' => ['voiceConfig' => ['prebuiltVoiceConfig' => ['voiceName' => 'Kore']]],
            ],
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong. Please try again.'], 400);
    }

    $fallback_models = ($action === 'tts') ? ['gemini-2.5-flash-preview-tts'] : ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash'];
    $last_error = 'The AI service is temporarily unavailable. Please try again.';
    $last_http_code = 500;

    foreach ($fallback_models as $model_to_try) {
        $gemini_api_url = $gemini_api_base . $model_to_try . ':generateContent?key=' . $api_key;
        
        $response = wp_remote_post($gemini_api_url, [
            'method' => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode($request_body),
            'timeout' => 45,
        ]);

        if (is_wp_error($response)) {
            $last_error = accessilens_sanitize_api_error($response->get_error_message());
            $last_http_code = 500;
            continue; 
        }

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);
        $http_code = (int) wp_remote_retrieve_response_code($response);

        if (isset($response_data['error'])) {
            $raw_msg = $response_data['error']['message'] ?? 'Unknown API error';
            if ($http_code === 404 || false !== strpos(strtolower($raw_msg), 'not found') || false !== strpos(strtolower($raw_msg), 'model')) {
                $last_error = accessilens_sanitize_api_error($raw_msg, $http_code);
                $last_http_code = $http_code;
                continue; 
            }
            return new WP_REST_Response(['success' => false, 'message' => accessilens_sanitize_api_error($raw_msg, $http_code)], 400);
        }

        if ($action === 'tts') {
            $audio_content = $response_data['candidates'][0]['content']['parts'][0]['inlineData']['data'] ?? null;
            if ($audio_content) {
                accessilens_track_usage('readAloud', $params);
                
                $hash = md5($text_to_speak);
                $upload_dir = wp_upload_dir();
                $cache_dir = $upload_dir['basedir'] . '/accessilens/tts';
                $cache_file = $cache_dir . '/' . $hash . '.txt';
                
                if (!file_exists($cache_dir)) {
                    wp_mkdir_p($cache_dir);
                }
                file_put_contents($cache_file, $audio_content);
                
                return new WP_REST_Response(['success' => true, 'audioContent' => $audio_content], 200);
            }
        } else {
            $text_content = $response_data['candidates'][0]['content']['parts'][0]['text'] ?? null;
            if ($text_content) {
                $feature = isset($params['feature']) ? sanitize_text_field($params['feature']) : 'textLens';
                accessilens_track_usage($feature, $params);
                return new WP_REST_Response(['success' => true, 'text' => $text_content], 200);
            }
        }
    }

    return new WP_REST_Response(['success' => false, 'message' => $last_error], $last_http_code);
}

// ─── Usage Tracking Helper ─────────────────────────────────────────────────────
// Uses blocking=true with a short timeout to ensure the request is actually
// dispatched (blocking=false silently drops on many shared hosts).
function accessilens_track_usage(string $feature, array $params = []): void
{
    $license_key = get_option('accessilens_license_key', '');
    if (empty($license_key)) {
        // Guideline 8: Never send telemetry without explicit license key consent
        return;
    }

    $admin_url = 'https://accessilens-ai.com/api/track';
    $domain = str_replace(['https://', 'http://'], '', get_site_url());
    $version = '1.8.256';

    $body = [
        'domain' => $domain,
        'feature' => $feature,
        'version' => $version,
        'licenseKey' => $license_key,
    ];

    $headers = ['Content-Type' => 'application/json'];

    $response = wp_remote_post($admin_url, [
        'method' => 'POST',
        'timeout' => 3,
        'blocking' => true,
        'headers' => $headers,
        'body' => json_encode($body),
    ]);

    // Log tracking failures for debugging (visible in WP debug.log)
    if (is_wp_error($response)) {
        
    } else {
        $code = wp_remote_retrieve_response_code($response);
        if ($code >= 400) {
            $resp_body = wp_remote_retrieve_body($response);
            
        }
    }
}
