<?php
/**
 * Plugin Name:       AccessiLens AI
 * Description:       An AI-powered, embeddable accessibility tool to assist users and ensure website compliance.
 * Version:           1.7.43
 * Author:            AccessiLens AI Team
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       accessilens-ai
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// 0. Admin Notices for pending configuration
function accessilens_ai_admin_notices()
{
    // Only show for admins
    if (!current_user_can('manage_options')) {
        return;
    }

    $screen = get_current_screen();
    // Don't show on our own settings page as we already have local notices there
    if ($screen && $screen->id === 'settings_page_accessilens-ai-settings') {
        return;
    }

    $api_key = get_option('accessilens_ai_api_key', '');
    $license_key = get_option('accessilens_license_key', '');
    
    $pending = [];
    if (empty($api_key)) $pending[] = 'Google Gemini API Key';
    if (empty($license_key)) $pending[] = 'AccessiLens License Key';

    if (!empty($pending)) {
        $settings_url = admin_url('options-general.php?page=accessilens-ai-settings');
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>AccessiLens AI:</strong> Configuration pending. Please add your 
                <?php echo implode(' and ', array_map(function($item) { return "<strong>$item</strong>"; }, $pending)); ?> 
                in the <a href="<?php echo esc_url($settings_url); ?>">settings page</a> to activate AI features and usage tracking.
            </p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'accessilens_ai_admin_notices');

// 1. Create admin page
function accessilens_ai_create_admin_page()
{
    add_options_page(
        'AccessiLens AI Settings',
        'AccessiLens AI',
        'manage_options',
        'accessilens-ai-settings',
        'accessilens_ai_settings_page_content'
    );
}
add_action('admin_menu', 'accessilens_ai_create_admin_page');

// 1b. Add "Settings" link on the Plugins list page
function accessilens_ai_plugin_action_links($links)
{
    $settings_link = '<a href="' . admin_url('options-general.php?page=accessilens-ai-settings') . '">' . __('Settings', 'accessilens-ai') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'accessilens_ai_plugin_action_links');

// 2. Handle settings page display and saving
function accessilens_ai_settings_page_content()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['accessilens_nonce']) && wp_verify_nonce($_POST['accessilens_nonce'], 'accessilens_save_settings')) {
        $api_key = isset($_POST['accessilens_ai_api_key']) ? sanitize_text_field($_POST['accessilens_ai_api_key']) : '';
        $license_key = isset($_POST['accessilens_license_key']) ? sanitize_text_field($_POST['accessilens_license_key']) : '';
        
        if (empty($api_key) || empty($license_key)) {
            echo '<div class="notice notice-error is-dismissible"><p><strong>Error:</strong> Both License Key and Gemini API Key are required to save changes.</p></div>';
        } else {
            update_option('accessilens_ai_api_key', $api_key);
            update_option('accessilens_license_key', $license_key);

            // Save New Widget Customizer Settings
            $color = sanitize_hex_color($_POST['accessilens_icon_color'] ?? '#2563eb');
            $position = sanitize_text_field($_POST['accessilens_icon_position'] ?? 'bottom-right');
            $iconType = sanitize_text_field($_POST['accessilens_icon_type'] ?? 'person');
            $iconShape = sanitize_text_field($_POST['accessilens_icon_shape'] ?? 'round');
            $ttsVoice = sanitize_text_field($_POST['accessilens_tts_voice'] ?? '');

            update_option('accessilens_icon_color', $color);
            update_option('accessilens_icon_position', $position);
            update_option('accessilens_icon_type', $iconType);
            update_option('accessilens_icon_shape', $iconShape);
            update_option('accessilens_tts_voice', $ttsVoice);

            // SYNC TO CLOUD RUN BACKEND
            $current_domain = str_replace(['https://', 'http://'], '', get_site_url());
            $update_url = "https://accessilens-ai.com/api/widget/update?domain=" . urlencode($current_domain) . "&clientId=" . urlencode($license_key);
            
            $response = wp_remote_post($update_url, [
                'method' => 'POST',
                'headers' => ['Content-Type' => 'application/json'],
                'body' => json_encode([
                    'color' => $color,
                    'position' => $position,
                    'iconType' => $iconType,
                    'iconShape' => $iconShape
                ]),
                'timeout' => 15,
                'blocking' => true 
            ]);

            if (is_wp_error($response)) {
                error_log("AccessiLens Update Failed: " . $response->get_error_message());
            } else {
                $status = wp_remote_retrieve_response_code($response);
                if ($status !== 200) {
                    error_log("AccessiLens Update Failed with status $status: " . wp_remote_retrieve_body($response));
                }
            }

            // Sanitize Custom CSS
            $custom_css = isset($_POST['accessilens_custom_css']) ? $_POST['accessilens_custom_css'] : '';
            $sanitized_css = wp_strip_all_tags(stripslashes($custom_css));
            update_option('accessilens_custom_css', $sanitized_css);

        // Purge popular caches to ensure settings apply immediately
        if (function_exists('wp_cache_clear_cache')) {
            wp_cache_clear_cache();
        } // WP Super Cache
        if (function_exists('w3tc_flush_all')) {
            w3tc_flush_all();
        } // W3 Total Cache
        if (function_exists('rocket_clean_domain')) {
            rocket_clean_domain();
        } // WP Rocket
        if (class_exists('LiteSpeed_Cache_API') && method_exists('LiteSpeed_Cache_API', 'purge_all')) {
            LiteSpeed_Cache_API::purge_all();
        } // LiteSpeed
        if (class_exists('autoptimizeCache') && method_exists('autoptimizeCache', 'clearall')) {
            autoptimizeCache::clearall();
        } // Autoptimize

        echo '<div class="notice notice-success is-dismissible"><p>Settings saved and website cache purged successfully.</p></div>';
        }
    }

    $saved_api_key = get_option('accessilens_ai_api_key', '');
    $saved_license_key = get_option('accessilens_license_key', '');
    $saved_css = get_option('accessilens_custom_css', '');
    $is_licensed = !empty($saved_license_key);
    ?>
    <div class="wrap">
        <h1 style="display:inline-block; margin-right:12px;"><?php echo esc_html(get_admin_page_title()); ?></h1>
        <span style="background:#e2e8f0; color:#475569; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:bold; vertical-align:middle; position:relative; top:-2px;">v1.4.0</span>
        <form method="POST" action="">
            <?php wp_nonce_field('accessilens_save_settings', 'accessilens_nonce'); ?>

            <h2>AccessiLens License Key</h2>
            <p>
                Get your free license key at
                <a href="https://accessilens-ai.com/portal"
                    target="_blank"><strong>AccessiLens Portal</strong></a>.
                Paste it below to activate tracking and unlock your plan's call limit.
            </p>
            <?php if ($is_licensed): ?>
                <div
                    style="background:#f0fdf4;border:1px solid #86efac;padding:10px 14px;border-radius:6px;margin-bottom:12px;color:#166534;">
                    ✅ <strong>License active</strong> — your usage is being tracked in the AccessiLens dashboard.
                </div>
            <?php else: ?>
                <div
                    style="background:#fefce8;border:1px solid #fde047;padding:10px 14px;border-radius:6px;margin-bottom:12px;color:#854d0e;">
                    ⚠️ No license key — the plugin works but usage is <strong>not tracked</strong>. Add a key to see your stats.
                </div>
            <?php endif; ?>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row"><label for="accessilens_license_key">License Key</label></th>
                        <td>
                            <input name="accessilens_license_key" type="text" id="accessilens_license_key"
                                value="<?php echo esc_attr($saved_license_key); ?>" class="regular-text"
                                placeholder="al_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" required>
                            <p class="description">Your unique AccessiLens license key. Check your <a href="https://accessilens-ai.com/portal" target="_blank">AccessiLens Portal</a> for your current AI call limits.</p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <h2>Google Gemini API Key</h2>
            <p>Enter your API key below. You can obtain a key from the <a href="https://ai.google.dev/"
                    target="_blank">Google AI Studio</a>. This key is stored securely on your server and is never exposed to
                website visitors.</p>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row"><label for="accessilens_ai_api_key">Gemini API Key</label></th>
                        <td><input name="accessilens_ai_api_key" type="password" id="accessilens_ai_api_key"
                                value="<?php echo esc_attr($saved_api_key); ?>" class="regular-text"
                                placeholder="Enter your Gemini API key" required></td>
                    </tr>
                </tbody>
            </table>

            <hr>

            <style>
                .al-card {
                    background: #fff;
                    border: 1px solid #e2e8f0;
                    border-radius: 12px;
                    padding: 24px;
                    margin-bottom: 24px;
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
                }
                .al-section-title {
                    font-size: 1.25rem;
                    font-weight: 800;
                    color: #0f172a;
                    margin: 0 0 8px 0;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .al-section-desc {
                    color: #64748b;
                    font-size: 0.875rem;
                    margin-bottom: 20px;
                }
                .form-table th {
                    width: 200px;
                    font-weight: 700;
                    color: #334155;
                }
                .al-badge {
                    display: inline-flex;
                    align-items: center;
                    padding: 4px 12px;
                    border-radius: 9999px;
                    font-size: 11px;
                    font-weight: 800;
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                }
            </style>

            <div class="al-card">
                <h2 class="al-section-title">🎨 Widget Customization</h2>
                <p class="al-section-desc">Configure how AccessiLens looks and behaves on your website. All customization is managed here in your plugin.</p>
                
                <?php
                $current_domain = str_replace(['https://', 'http://'], '', get_site_url());
                $verify_url = "https://accessilens-ai.com/api/widget/verify?domain=" . urlencode($current_domain) . "&clientId=" . urlencode($saved_license_key) . "&nocache=1";
                $verify_response = wp_remote_get($verify_url);
                $is_domain_verified = false;
                
                if (!is_wp_error($verify_response)) {
                    $verify_data = json_decode(wp_remote_retrieve_body($verify_response), true);
                    $is_domain_verified = $verify_data['valid'] ?? false;
                }
                ?>

                <div style="background:<?php echo $is_domain_verified ? '#f0fdf4' : '#fef2f2'; ?>; border: 1px solid <?php echo $is_domain_verified ? '#86efac' : '#fecaca'; ?>; padding: 16px; border-radius: 10px; margin-bottom: 24px;">
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <div>
                            <span class="al-badge" style="background:<?php echo $is_domain_verified ? '#dcfce7' : '#fee2e2'; ?>; color:<?php echo $is_domain_verified ? '#166534' : '#991b1b'; ?>;">
                                <?php echo $is_domain_verified ? '🛡️ Domain Active' : '⚠️ Unauthorized'; ?>
                            </span>
                            <p style="margin:8px 0 0 0; font-size:13px; font-weight:500; color:<?php echo $is_domain_verified ? '#166534' : '#991b1b'; ?>;">
                                <?php if ($is_domain_verified): ?>
                                    Domain <strong><?php echo esc_html($current_domain); ?></strong> is verified.
                                <?php else: ?>
                                    Domain <strong><?php echo esc_html($current_domain); ?></strong> is not whitelisted. The widget will <strong>not appear</strong> on your website until you add this domain in your <a href="https://accessilens-ai.com/portal/account" target="_blank" style="color:inherit; font-weight:700; text-decoration:underline;">AccessiLens Portal → Domain Firewall</a>.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>

                <?php
                $color = esc_attr(get_option('accessilens_icon_color', '#2563eb'));
                $pos = get_option('accessilens_icon_position', 'bottom-right');
                $type = get_option('accessilens_icon_type', 'person');
                $shape = get_option('accessilens_icon_shape', 'round');
                $ttsVoice = get_option('accessilens_tts_voice', '');
                ?>

                <style>
                    .al-customizer-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
                    @media (max-width: 782px) { .al-customizer-grid { grid-template-columns: 1fr; } }
                    .al-field-label { display: block; font-size: 13px; font-weight: 700; color: #1e293b; margin-bottom: 8px; }
                    .al-color-row { display: flex; align-items: center; gap: 12px; }
                    .al-color-picker { width: 48px; height: 48px; border-radius: 12px; border: 2px solid #e2e8f0; cursor: pointer; padding: 2px; }
                    .al-color-hex { flex: 1; padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 10px; font-family: monospace; font-size: 14px; background: #f8fafc; }
                    .al-select { width: 100%; padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 10px; font-size: 14px; background: #f8fafc; appearance: auto; }
                    .al-icon-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(70px, 1fr)); gap: 10px; }
                    .al-icon-btn { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 14px 8px; border: 2px solid #e2e8f0; border-radius: 12px; background: #fff; cursor: pointer; transition: all 0.2s; }
                    .al-icon-btn:hover { border-color: #cbd5e1; background: #f8fafc; }
                    .al-icon-btn.active { border-color: #4f46e5; background: #eef2ff; }
                    .al-icon-btn svg { width: 28px; height: 28px; fill: none; stroke: #94a3b8; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; transition: all 0.2s; }
                    .al-icon-btn.active svg { stroke: #4f46e5; }
                    .al-icon-btn svg[fill="currentColor"] { fill: #94a3b8; stroke: none; stroke-width: 0; }
                    .al-icon-btn.active svg[fill="currentColor"] { fill: #4f46e5; stroke: none; }
                    .al-icon-btn span { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #94a3b8; margin-top: 6px; }
                    .al-icon-btn.active span { color: #4f46e5; }
                    .al-preview-panel { background: #0f172a; border-radius: 16px; padding: 20px; position: relative; min-height: 280px; overflow: hidden; }
                    .al-preview-label { color: rgba(255,255,255,0.3); font-size: 9px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.15em; position: absolute; top: 16px; left: 20px; }
                    .al-preview-viewport { position: relative; width: 100%; height: 220px; background: rgba(255,255,255,0.04); border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); margin-top: 28px; }
                    .al-preview-hint { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: rgba(255,255,255,0.15); font-size: 11px; text-align: center; max-width: 200px; line-height: 1.5; }
                    .al-preview-fab { position: absolute; width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
                    .al-preview-fab svg { width: 28px; height: 28px; color: #fff; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
                    .al-preview-fab svg[fill="currentColor"] { fill: #fff; stroke: none; stroke-width: 0; }
                </style>

                <div class="al-customizer-grid">
                    <!-- LEFT: Controls -->
                    <div>
                        <!-- Primary Brand Color -->
                        <div style="margin-bottom: 20px;">
                            <label class="al-field-label">Primary Brand Color</label>
                            <div class="al-color-row">
                                <input name="accessilens_icon_color" type="color" id="accessilens_icon_color" value="<?php echo $color; ?>" class="al-color-picker">
                                <input type="text" id="accessilens_color_hex" value="<?php echo $color; ?>" class="al-color-hex" maxlength="7" pattern="#[0-9a-fA-F]{6}">
                            </div>
                        </div>

                        <!-- Position + Shape Row -->
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px;">
                            <div>
                                <label class="al-field-label">Float Position</label>
                                <select name="accessilens_icon_position" id="accessilens_icon_position" class="al-select">
                                    <option value="bottom-right" <?php selected($pos, 'bottom-right'); ?>>Bottom Right</option>
                                    <option value="bottom-left" <?php selected($pos, 'bottom-left'); ?>>Bottom Left</option>
                                    <option value="top-right" <?php selected($pos, 'top-right'); ?>>Top Right</option>
                                    <option value="top-left" <?php selected($pos, 'top-left'); ?>>Top Left</option>
                                    <option value="middle-left" <?php selected($pos, 'middle-left'); ?>>Middle Left</option>
                                    <option value="middle-right" <?php selected($pos, 'middle-right'); ?>>Middle Right</option>
                                </select>
                            </div>
                            <div>
                                <label class="al-field-label">Button Shape</label>
                                <select name="accessilens_icon_shape" id="accessilens_icon_shape" class="al-select">
                                    <option value="round" <?php selected($shape, 'round'); ?>>Circle (Round)</option>
                                    <option value="rounded" <?php selected($shape, 'rounded'); ?>>Squircle</option>
                                    <option value="square" <?php selected($shape, 'square'); ?>>Square</option>
                                </select>
                            </div>
                        </div>

                        <!-- Voice Selection Row -->
                        <div style="margin-bottom:20px;">
                            <label class="al-field-label">Read Aloud Voice</label>
                            <select name="accessilens_tts_voice" id="accessilens_tts_voice" class="al-select">
                                <option value="" <?php selected($ttsVoice, ''); ?>>Auto / Default</option>
                                <option value="Female" <?php selected($ttsVoice, 'Female'); ?>>Prefer Female Voice</option>
                                <option value="Male" <?php selected($ttsVoice, 'Male'); ?>>Prefer Male Voice</option>
                                <option value="Google US English" <?php selected($ttsVoice, 'Google US English'); ?>>Google US English</option>
                                <option value="Google UK English Female" <?php selected($ttsVoice, 'Google UK English Female'); ?>>Google UK English Female</option>
                                <option value="Google UK English Male" <?php selected($ttsVoice, 'Google UK English Male'); ?>>Google UK English Male</option>
                                <option value="Samantha" <?php selected($ttsVoice, 'Samantha'); ?>>Samantha (Mac/iOS)</option>
                                <option value="Daniel" <?php selected($ttsVoice, 'Daniel'); ?>>Daniel (Mac/iOS)</option>
                                <option value="Microsoft Zira" <?php selected($ttsVoice, 'Microsoft Zira'); ?>>Microsoft Zira (Windows)</option>
                                <option value="Microsoft David" <?php selected($ttsVoice, 'Microsoft David'); ?>>Microsoft David (Windows)</option>
                            </select>
                        </div>

                        <!-- Widget Icon Grid -->
                        <div style="margin-bottom: 20px;">
                            <label class="al-field-label">Widget Icon</label>
                            <input type="hidden" name="accessilens_icon_type" id="accessilens_icon_type" value="<?php echo esc_attr($type); ?>">
                            <div class="al-icon-grid">
                                <button type="button" class="al-icon-btn <?php echo $type === 'person' ? 'active' : ''; ?>" data-icon="person" title="Person">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg>
                                    <span>Person</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'accessible' ? 'active' : ''; ?>" data-icon="accessible" title="Universal Access">
                                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z"/></svg>
                                    <span>Access</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'wheelchair' ? 'active' : ''; ?>" data-icon="wheelchair" title="Modern Wheelchair">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="4" r="2"/><path d="M10 6v5h5l2.5 6"/><circle cx="8.5" cy="17.5" r="3.5"/><path d="M15 17.5h4"/></svg>
                                    <span>Wheelchair</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'eye' ? 'active' : ''; ?>" data-icon="eye" title="Eye / Vision">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <span>Eye</span>
                                </button>
                                <button type="button" class="al-icon-btn <?php echo $type === 'clean' ? 'active' : ''; ?>" data-icon="clean" title="Clean / Sparkles">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
                                    <span>Clean</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- RIGHT: Live Preview -->
                    <div class="al-preview-panel">
                        <span class="al-preview-label">Live Preview</span>
                        <div class="al-preview-viewport" id="al-preview-viewport">
                            <span class="al-preview-hint">This is how the widget will appear on your website.</span>
                            <div class="al-preview-fab" id="al-preview-fab">
                                <!-- Icon injected by JS -->
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                (function() {
                    const iconSVGs = {
                        person: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg>',
                        accessible: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z"/></svg>',
                        wheelchair: '<svg viewBox="0 0 24 24"><circle cx="10" cy="4" r="2"/><path d="M10 6v5h5l2.5 6"/><circle cx="8.5" cy="17.5" r="3.5"/><path d="M15 17.5h4"/></svg>',
                        eye: '<svg viewBox="0 0 24 24"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>',
                        clean: '<svg viewBox="0 0 24 24"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>'
                    };

                    const fab = document.getElementById('al-preview-fab');
                    const colorInput = document.getElementById('accessilens_icon_color');
                    const colorHex = document.getElementById('accessilens_color_hex');
                    const posSelect = document.getElementById('accessilens_icon_position');
                    const shapeSelect = document.getElementById('accessilens_icon_shape');
                    const iconHidden = document.getElementById('accessilens_icon_type');
                    const iconBtns = document.querySelectorAll('.al-icon-btn[data-icon]');

                    function updatePreview() {
                        const color = colorInput.value;
                        const pos = posSelect.value;
                        const shape = shapeSelect.value;
                        const icon = iconHidden.value;

                        // Color
                        fab.style.backgroundColor = color;

                        // Shape
                        if (shape === 'round') { fab.style.borderRadius = '9999px'; fab.style.width = '56px'; fab.style.padding = '0'; }
                        else if (shape === 'rounded') { fab.style.borderRadius = '20px'; fab.style.width = '56px'; fab.style.padding = '0'; }
                        else if (shape === 'square') { fab.style.borderRadius = '0'; fab.style.width = '56px'; fab.style.padding = '0'; }

                        // Position
                        fab.style.top = fab.style.bottom = fab.style.left = fab.style.right = fab.style.transform = 'auto';
                        fab.style.transform = 'none';
                        if (pos === 'bottom-right') { fab.style.bottom = '16px'; fab.style.right = '16px'; }
                        else if (pos === 'bottom-left') { fab.style.bottom = '16px'; fab.style.left = '16px'; }
                        else if (pos === 'top-right') { fab.style.top = '16px'; fab.style.right = '16px'; }
                        else if (pos === 'top-left') { fab.style.top = '16px'; fab.style.left = '16px'; }
                        else if (pos === 'middle-left') { fab.style.top = '50%'; fab.style.left = '16px'; fab.style.transform = 'translateY(-50%)'; }
                        else if (pos === 'middle-right') { fab.style.top = '50%'; fab.style.right = '16px'; fab.style.transform = 'translateY(-50%)'; }

                        // Icon
                        fab.innerHTML = iconSVGs[icon] || iconSVGs.person;
                    }

                    // Sync color picker ↔ hex input
                    colorInput.addEventListener('input', function() { colorHex.value = this.value; updatePreview(); });
                    colorHex.addEventListener('input', function() {
                        if (/^#[0-9a-fA-F]{6}$/.test(this.value)) { colorInput.value = this.value; updatePreview(); }
                    });

                    posSelect.addEventListener('change', updatePreview);
                    shapeSelect.addEventListener('change', updatePreview);

                    // Icon grid click
                    iconBtns.forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            iconBtns.forEach(function(b) { b.classList.remove('active'); });
                            btn.classList.add('active');
                            iconHidden.value = btn.dataset.icon;
                            updatePreview();
                        });
                    });

                    // Initial render
                    updatePreview();
                })();
                </script>
            </div>

            <hr>

            <h2>Advanced Styling</h2>
            <div style="margin-bottom: 15px;">
                <button type="button" id="accessilens_ai_stylist" class="button" style="background: #2563eb; color: white; border: none;">✨ Generate AI Stylist Fixes</button>
                <span id="ai_stylist_status" style="margin-left: 10px; font-weight: bold;"></span>
            </div>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row"><label for="accessilens_custom_css">Custom CSS Overrides</label></th>
                        <td>
                            <textarea name="accessilens_custom_css" id="accessilens_custom_css" rows="10" cols="50"
                                class="large-text code"
                                placeholder="/* Add custom CSS to fix accessibility issues */"><?php echo esc_textarea($saved_css); ?></textarea>
                            <p class="description">These styles are injected into your website to fix accessibility issues. Use the AI Stylist button above for automated fixes.</p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <script>
            document.getElementById('accessilens_ai_stylist').addEventListener('click', async function() {
                const btn = this;
                const status = document.getElementById('ai_stylist_status');
                btn.disabled = true;
                status.innerText = 'Analyzing site...';
                status.style.color = '#2563eb';

                try {
                    const response = await fetch('<?php echo rest_url("accessilens-ai/v1/proxy"); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': '<?php echo wp_create_nonce("wp_rest"); ?>'
                        },
                        body: JSON.stringify({
                            action: 'ai-stylist',
                            html: document.documentElement.innerHTML.substring(0, 10000) // Sample HTML
                        })
                    });
                    const data = await response.json();
                    if (data.success && data.text) {
                        const cssArea = document.getElementById('accessilens_custom_css');
                        cssArea.value += "\n\n/* AI Generated Fixes */\n" + data.text;
                        status.innerText = 'Success! AI fixes added below.';
                        status.style.color = '#059669';
                    } else {
                        status.innerText = 'Error: ' + (data.message || 'AI failed to generate styles.');
                        status.style.color = '#dc2626';
                    }
                } catch (e) {
                    status.innerText = 'Connection error.';
                    status.style.color = '#dc2626';
                } finally {
                    btn.disabled = false;
                }
            });
            </script>


            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// 3. Enqueue scripts and styles on the frontend
function accessilens_ai_enqueue_scripts()
{
    // **STABILITY FIX**: Prevent the widget from loading on admin, login, and registration pages.
    if (is_admin() || in_array($GLOBALS['pagenow'], ['wp-login.php', 'wp-register.php'])) {
        return;
    }

    // ── CDN Auto-Update ──
    // Check the CDN for a newer widget version (at most once per hour).
    // If a newer version exists, download widget.js and widget.css to the
    // local plugin folder so the latest code is always served without
    // requiring a manual plugin ZIP upload.
    $cdn_base = 'https://accessilens-ai.com';
    $check_transient = 'accessilens_cdn_check';
    $local_js  = plugin_dir_path(__FILE__) . 'accessilens.js';
    $local_css = plugin_dir_path(__FILE__) . 'accessilens.css';

    if (false === get_transient($check_transient)) {
        $version_response = wp_remote_get($cdn_base . '/version.json', ['timeout' => 5, 'sslverify' => true]);
        if (!is_wp_error($version_response) && wp_remote_retrieve_response_code($version_response) === 200) {
            $version_data = json_decode(wp_remote_retrieve_body($version_response), true);
            $cdn_timestamp = $version_data['timestamp'] ?? '';
            $local_timestamp = get_option('accessilens_widget_timestamp', '');

            if (!empty($cdn_timestamp) && $cdn_timestamp !== $local_timestamp) {
                // Download new widget.js
                $js_response = wp_remote_get($cdn_base . '/widget.js', ['timeout' => 15, 'sslverify' => true]);
                if (!is_wp_error($js_response) && wp_remote_retrieve_response_code($js_response) === 200) {
                    $js_content = wp_remote_retrieve_body($js_response);
                    if (strlen($js_content) > 10000) { // Sanity check — widget should be > 10KB
                        file_put_contents($local_js, $js_content);
                    }
                }
                // Download new widget.css
                $css_response = wp_remote_get($cdn_base . '/widget.css', ['timeout' => 15, 'sslverify' => true]);
                if (!is_wp_error($css_response) && wp_remote_retrieve_response_code($css_response) === 200) {
                    $css_content = wp_remote_retrieve_body($css_response);
                    if (strlen($css_content) > 1000) { // Sanity check — CSS should be > 1KB
                        file_put_contents($local_css, $css_content);
                    }
                }
                update_option('accessilens_widget_timestamp', $cdn_timestamp);
            }
        }
        // Check at most once per hour
        set_transient($check_transient, 'checked', HOUR_IN_SECONDS);
    }

    $script_file = $local_js;
    $script_version = file_exists($script_file) ? filemtime($script_file) : '1.4.0';
    $script_url = plugin_dir_url(__FILE__) . 'accessilens.js?v=' . $script_version;

    wp_enqueue_script('accessilens-ai-script', $script_url, [], $script_version, false);
    
    $style_file = $local_css;
    $style_version = file_exists($style_file) ? filemtime($style_file) : '1.4.0';
    $style_url = plugin_dir_url(__FILE__) . 'accessilens.css?v=' . $style_version;
    wp_enqueue_style('accessilens-ai-style', $style_url, [], $style_version);
    
    // **CORRUPTION FIX**: Explicitly mark the script to be ignored by minifiers (Autoptimize, WP Rocket, etc.)
    add_filter('script_loader_tag', function($tag, $handle) {
        if ('accessilens-ai-script' !== $handle) return $tag;
        // Add data-cfasync="false" for Cloudflare and data-no-minify="1" for WP Rocket
        return str_replace('<script', '<script data-cfasync="false" data-no-optimize="1" data-no-minify="1" data-no-defer="1"', $tag);
    }, 10, 2);

    // **SECURITY**: Pass a proxy URL and a nonce instead of the raw API key.
    wp_localize_script(
        'accessilens-ai-script',
        'accessilensData',
        [
            'pluginUrl' => plugin_dir_url(__FILE__),
            'proxyUrl' => rest_url('accessilens-ai/v1/proxy'),
            'nonce' => wp_create_nonce('wp_rest'),
            'licenseKey' => get_option('accessilens_license_key', ''),
            'iconPosition' => get_option('accessilens_icon_position', 'bottom-right'),
            'iconShape' => get_option('accessilens_icon_shape', 'round'),
            'iconColor' => get_option('accessilens_icon_color', '#2563EB'),
            'iconType' => get_option('accessilens_icon_type', 'person'),
            'ttsVoice' => get_option('accessilens_tts_voice', ''),
            'logoUrl' => get_option('accessilens_logo_url', ''),
            'defaultMode' => get_option('accessilens_default_mode', 'light'),
            'customCSS' => get_option('accessilens_custom_css', ''),
        ]
    );
}
add_action('wp_enqueue_scripts', 'accessilens_ai_enqueue_scripts', 999);

// 4. **SECURITY**: Create a secure REST API endpoint to act as a proxy
function accessilens_ai_register_proxy_endpoint()
{
    register_rest_route('accessilens-ai/v1', '/proxy', [
        'methods' => 'POST',
        'callback' => 'accessilens_ai_proxy_handler',
        'permission_callback' => function ($request) {
            // **SECURITY**: Verify the nonce passed in the header.
            return wp_verify_nonce($request->get_header('x_wp_nonce'), 'wp_rest');
        },
    ]);
}
add_action('rest_api_init', 'accessilens_ai_register_proxy_endpoint');

// ─── Error Sanitizer — never expose raw API errors to users ──────────────────
function accessilens_sanitize_api_error(string $raw_message, int $status_code = 0): string
{
    $lower = strtolower($raw_message);

    // Quota / rate-limit errors
    if (str_contains($lower, 'quota') || str_contains($lower, 'rate') || $status_code === 429) {
        return 'The Google Gemini API Key you provided has reached its usage limit. Please upgrade your Google AI Studio plan to continue using AI features.';
    }
    // Auth / API key errors
    if (str_contains($lower, 'api key') || str_contains($lower, 'permission') || str_contains($lower, 'forbidden') || $status_code === 403) {
        return 'The AI service could not authenticate. Please ask the site administrator to verify the API key in Settings → AccessiLens AI.';
    }
    // Safety / content filtering
    if (str_contains($lower, 'safety') || str_contains($lower, 'blocked') || str_contains($lower, 'harm')) {
        return 'This content could not be processed due to safety guidelines. Please try different content.';
    }
    // Model not found
    if (str_contains($lower, 'not found') || str_contains($lower, 'model')) {
        return 'The AI model is temporarily unavailable. Please try again in a moment.';
    }
    // Timeout / connection errors
    if (str_contains($lower, 'timeout') || str_contains($lower, 'timed out') || str_contains($lower, 'curl error')) {
        return 'The AI service is temporarily unavailable. Please try again in a few seconds.';
    }
    // Generic fallback — never expose raw message
    return 'Something went wrong with the AI service. Please try again.';
}

// 5. **SECURITY**: Handle the proxy request on the server
function accessilens_ai_proxy_handler(WP_REST_Request $request)
{
    $api_key = get_option('accessilens_ai_api_key');
    if (empty($api_key)) {
        return new WP_REST_Response(['success' => false, 'message' => 'AI features are not available. Please ask the site administrator to configure the Gemini API key in Settings → AccessiLens AI.'], 400);
    }

    // **SECURITY**: Simple Rate Limiting (max 60 requests per minute per IP)
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $transient_key = 'accessilens_rate_' . md5($ip);
    $request_count = (int) get_transient($transient_key);

    if ($request_count > 60) {
        return new WP_REST_Response(['success' => false, 'message' => 'You\'re using AI features too quickly. Please wait a moment and try again.'], 429);
    }
    set_transient($transient_key, $request_count + 1, MINUTE_IN_SECONDS);

    $params = $request->get_json_params();
    $action = isset($params['action']) ? sanitize_text_field($params['action']) : '';

    $gemini_api_base = 'https://generativelanguage.googleapis.com/v1beta/models/';
    $request_body = [];
    $model = '';

    if ($action === 'generateContent') {
        $request_body = ['contents' => $params['contents']];

        // **IMAGE LENS FIX**: Process imageUrl server-side to bypass CORS
        if (isset($request_body['contents'][0]['parts'])) {
            foreach ($request_body['contents'][0]['parts'] as $key => $part) {
                if (isset($part['imageUrl'])) {
                    $image_url = esc_url_raw($part['imageUrl']);
                    $image_response = wp_remote_get($image_url, ['timeout' => 20]);

                    if (is_wp_error($image_response) || wp_remote_retrieve_response_code($image_response) !== 200) {
                        return new WP_REST_Response(['success' => false, 'message' => 'We couldn\'t load this image for analysis. The image may be protected or unavailable.'], 500);
                    }

                    // **SECURITY**: Prevent massive file downloads (limit to 5MB)
                    $image_size = (int) wp_remote_retrieve_header($image_response, 'content-length');
                    if ($image_size > 5 * 1024 * 1024) {
                        return new WP_REST_Response(['success' => false, 'message' => 'This image is too large to analyze (max 5 MB). Please try a smaller image.'], 400);
                    }

                    $image_data = wp_remote_retrieve_body($image_response);
                    $mime_type = wp_remote_retrieve_header($image_response, 'content-type');

                    // Replace imageUrl part with inlineData part for Gemini
                    unset($request_body['contents'][0]['parts'][$key]['imageUrl']);
                    $request_body['contents'][0]['parts'][$key]['inlineData'] = [
                        'mimeType' => $mime_type ?: 'image/jpeg',
                        'data' => base64_encode($image_data)
                    ];
                }
            }
        }
    } elseif ($action === 'tts') {
        // Robust text sanitization for TTS
        $text_to_speak = isset($params['text']) ? $params['text'] : '';
        $text_to_speak = html_entity_decode($text_to_speak);
        $text_to_speak = wp_strip_all_tags($text_to_speak);
        $text_to_speak = preg_replace('/\s+/', ' ', $text_to_speak);
        $text_to_speak = trim($text_to_speak);

        if (empty($text_to_speak)) {
            return new WP_REST_Response(['success' => false, 'message' => 'No text found on this page to read aloud.'], 400);
        }
        $model = 'gemini-2.5-flash-preview-tts';
        $request_body = [
            'contents' => [['parts' => [['text' => $text_to_speak]]]],
            'generationConfig' => [
                'responseModalities' => ['AUDIO'],
                'speechConfig' => ['voiceConfig' => ['prebuiltVoiceConfig' => ['voiceName' => 'Kore']]],
            ],
        ];
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Something went wrong. Please try again.'], 400);
    }

    $fallback_models = ($action === 'tts') ? ['gemini-2.5-flash-preview-tts'] : ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash'];
    $last_error = 'The AI service is temporarily unavailable. Please try again.';
    $last_http_code = 500;

    foreach ($fallback_models as $model_to_try) {
        $gemini_api_url = $gemini_api_base . $model_to_try . ':generateContent?key=' . $api_key;
        
        $response = wp_remote_post($gemini_api_url, [
            'method' => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode($request_body),
            'timeout' => 45,
        ]);

        if (is_wp_error($response)) {
            $last_error = accessilens_sanitize_api_error($response->get_error_message());
            $last_http_code = 500;
            continue; 
        }

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);
        $http_code = (int) wp_remote_retrieve_response_code($response);

        if (isset($response_data['error'])) {
            $raw_msg = $response_data['error']['message'] ?? 'Unknown API error';
            if ($http_code === 404 || str_contains(strtolower($raw_msg), 'not found') || str_contains(strtolower($raw_msg), 'model')) {
                $last_error = accessilens_sanitize_api_error($raw_msg, $http_code);
                $last_http_code = $http_code;
                continue; 
            }
            return new WP_REST_Response(['success' => false, 'message' => accessilens_sanitize_api_error($raw_msg, $http_code)], 400);
        }

        if ($action === 'tts') {
            $audio_content = $response_data['candidates'][0]['content']['parts'][0]['inlineData']['data'] ?? null;
            if ($audio_content) {
                accessilens_track_usage('readAloud', $params);
                return new WP_REST_Response(['success' => true, 'audioContent' => $audio_content], 200);
            }
        } else {
            $text_content = $response_data['candidates'][0]['content']['parts'][0]['text'] ?? null;
            if ($text_content) {
                $feature = isset($params['feature']) ? sanitize_text_field($params['feature']) : 'textLens';
                accessilens_track_usage($feature, $params);
                return new WP_REST_Response(['success' => true, 'text' => $text_content], 200);
            }
        }
    }

    return new WP_REST_Response(['success' => false, 'message' => $last_error], $last_http_code);
}

// ─── Usage Tracking Helper ─────────────────────────────────────────────────────
// Uses blocking=true with a short timeout to ensure the request is actually
// dispatched (blocking=false silently drops on many shared hosts).
function accessilens_track_usage(string $feature, array $params = []): void
{
    $admin_url = 'https://accessilens-ai.com/api/track';
    $domain = str_replace(['https://', 'http://'], '', get_site_url());
    $license_key = get_option('accessilens_license_key', '');
    $version = '1.4.0';

    $body = [
        'domain' => $domain,
        'feature' => $feature,
        'version' => $version,
    ];

    $headers = ['Content-Type' => 'application/json'];

    if (!empty($license_key)) {
        // Registered user — send license key for proper attribution
        $body['licenseKey'] = $license_key;
    } else {
        // Anonymous fallback — use internal key
        $headers['x-track-key'] = 'accessilens_track_key_change_me';
        $body['userEmail'] = wp_get_current_user()->user_email ?? '';
        $body['userId'] = (string) (get_current_user_id() ?: '');
    }

    $response = wp_remote_post($admin_url, [
        'method' => 'POST',
        'timeout' => 3,
        'blocking' => true,
        'headers' => $headers,
        'body' => json_encode($body),
    ]);

    // Log tracking failures for debugging (visible in WP debug.log)
    if (is_wp_error($response)) {
        error_log('AccessiLens tracking failed: ' . $response->get_error_message());
    } else {
        $code = wp_remote_retrieve_response_code($response);
        if ($code >= 400) {
            $resp_body = wp_remote_retrieve_body($response);
            error_log("AccessiLens tracking returned HTTP $code: $resp_body");
        }
    }
}

// ─── Site Registration (runs on every page load, lightweight via transient) ─────
function accessilens_register_site(): void
{
    // Only re-register once per day to avoid hammering the endpoint
    if (get_transient('accessilens_registered'))
        return;

    $admin_url = 'https://accessilens-ai.com/api/register';
    $track_key = 'accessilens_track_key_change_me';
    $domain = str_replace(['https://', 'http://'], '', get_site_url());
    $admin_user = get_users(['role' => 'administrator', 'number' => 1]);
    $user_email = !empty($admin_user) ? $admin_user[0]->user_email : '';
    $version = get_option('accessilens_plugin_version', '1.4.0');

    wp_remote_post($admin_url, [
        'method' => 'POST',
        'timeout' => 3,
        'blocking' => false,
        'headers' => [
            'Content-Type' => 'application/json',
            'x-track-key' => $track_key,
        ],
        'body' => json_encode([
            'domain' => $domain,
            'userEmail' => $user_email,
            'plan' => 'free',
            'version' => $version,
        ]),
    ]);

    set_transient('accessilens_registered', true, DAY_IN_SECONDS);
}
add_action('wp_loaded', 'accessilens_register_site');

// ─── Auto-Update Integration ─────────────────────────────────────────

// 1. Check for updates and inject into WordPress update transient
function accessilens_ai_check_for_updates($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    $plugin_slug = plugin_basename(__FILE__);
    
    // We fetch the update check at most once every 6 hours
    $update_cache = get_transient('accessilens_update_cache');
    if ($update_cache === false) {
        $response = wp_remote_get('https://cdn.jsdelivr.net/gh/anshumanmaini/accessilens-cdn@main/version.json', ['timeout' => 5, 'sslverify' => true]);
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($data['version'])) {
                $update_cache = $data;
                set_transient('accessilens_update_cache', $update_cache, 6 * HOUR_IN_SECONDS);
            }
        }
    }

    if (!empty($update_cache)) {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $plugin_data = get_plugin_data(__FILE__);
        $current_version = $plugin_data['Version'];

        if (version_compare($current_version, $update_cache['version'], '<')) {
            $update = new stdClass();
            $update->id = $plugin_slug;
            $update->slug = 'accessilens-ai';
            $update->plugin = $plugin_slug;
            $update->new_version = $update_cache['version'];
            $update->url = 'https://accessilens-ai.com';
            $update->package = 'https://cdn.jsdelivr.net/gh/anshumanmaini/accessilens-cdn@main/accessilens-wp-plugin.zip';
            $update->icons = [
                '1x' => 'https://accessilens-ai.com/icon.png',
                '2x' => 'https://accessilens-ai.com/icon.png'
            ];
            
            $transient->response[$plugin_slug] = $update;
        } else {
            // No update needed
            $update = new stdClass();
            $update->id = $plugin_slug;
            $update->slug = 'accessilens-ai';
            $update->plugin = $plugin_slug;
            $update->new_version = $current_version;
            $update->url = 'https://accessilens-ai.com';
            $transient->no_update[$plugin_slug] = $update;
        }
    }

    return $transient;
}
add_filter('site_transient_update_plugins', 'accessilens_ai_check_for_updates');

// 2. Provide "View Details" plugin information modal
function accessilens_ai_plugin_info($false, $action, $response) {
    if ($action !== 'plugin_information') {
        return $false;
    }

    if (!isset($response->slug) || $response->slug !== 'accessilens-ai') {
        return $false;
    }

    $update_cache = get_transient('accessilens_update_cache');
    if (empty($update_cache)) {
        return $false;
    }

    $info = new stdClass();
    $info->name = 'AccessiLens AI';
    $info->slug = 'accessilens-ai';
    $info->version = $update_cache['version'];
    $info->author = '<a href="https://accessilens-ai.com">AccessiLens AI Team</a>';
    $info->homepage = 'https://accessilens-ai.com';
    $info->requires = '5.0';
    $info->tested = '6.4';
    $info->downloaded = 0;
    $info->last_updated = $update_cache['updatedAt'] ?? date('Y-m-d');
    $info->sections = [
        'description' => '<p>An AI-powered, embeddable accessibility tool to assist users and ensure website compliance.</p>',
        'changelog' => '<p>AccessiLens is continually updated with new AI features, performance improvements, and bug fixes to keep your website compliant.</p><p>For detailed release notes, please log into your <a href="https://accessilens-ai.com/portal" target="_blank">AccessiLens Portal</a>.</p>'
    ];
    $info->banners = [
        'low' => 'https://accessilens-ai.com/hero-art.png',
        'high' => 'https://accessilens-ai.com/hero-art.png'
    ];
    $info->download_link = 'https://cdn.jsdelivr.net/gh/anshumanmaini/accessilens-cdn@main/accessilens-wp-plugin.zip';

    return $info;
}
add_filter('plugins_api', 'accessilens_ai_plugin_info', 10, 3);
