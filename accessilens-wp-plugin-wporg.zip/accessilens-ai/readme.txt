=== AccessiLens AI ===
Contributors: anshumanmaini
Tags: accessibility, wcag, ada compliance, screen reader, ai alt text
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.8.253
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered accessibility toolbar that helps remediate WCAG 2.1 AA issues, adds screen reader support, high contrast, and accessibility tools.

== Description ==

**AccessiLens AI** makes your WordPress website more accessible, compliant, and welcoming for visitors with disabilities. With one lightweight install, AccessiLens equips your website with an intuitive accessibility widget and AI-driven remediation tools aligned with WCAG 2.1 AA and ADA standards.

Unlike generic accessibility overlays that only toggle CSS filters, AccessiLens combines essential client-side accessibility profiles with real-time AI assistance powered by Google Gemini.

### Key Features

* **Accessibility Profiles:** One-click presets for Motor Impaired, Blind & Screen Reader, Color Blindness, Dyslexia, ADHD, and Visual Impairment.
* **AI Alt-Text Generator:** Scans images missing alternative text and generates descriptive alt text using Google Gemini Vision (requires API key).
* **Neural Text-to-Speech (TTS):** Natural, high-quality read-aloud functionality with multiple voice accents and playback controls.
* **Reading & Visual Adjustments:** High contrast mode, dark contrast, monochrome, font scaling, line height, letter spacing, dyslexia-friendly font (OpenDyslexic), and big cursor.
* **Reading Mask & Guide:** Focus ruler and reading window for users with cognitive or attention challenges.
* **Dictionary Lookup:** Instant inline word definitions for cognitive assistance.
* **Keyboard Navigation:** High-visibility focus indicators and skip-to-content enhancements.
* **Multilingual Widget UI:** Built-in translations for English, Spanish, French, German, Italian, Portuguese, and Arabic.
* **Full Design Customization:** Customize widget floating position, brand colors, button shape, and icon style from your WordPress dashboard.

### Privacy & Performance

* **Zero Frontend Bloat:** Enqueues a single lightweight bundle (`accessilens.js` & `accessilens.css`). Excluded from login and admin pages.
* **Secure API Architecture:** Your Google Gemini API key is stored securely in your WordPress database and never exposed to website visitors. All AI requests route through a secure WordPress REST API proxy with nonce verification and IP rate limiting.
* **Privacy by Design:** No telemetry or external requests are sent unless you explicitly enter a license key.

== External or Third-Party Services ==

To provide its optional cloud and AI functionality, this plugin connects to the following external third-party services:

1. **AccessiLens Verification API (https://accessilens-ai.com)**
   * **Purpose:** Validates your AccessiLens License Key, authorizes your domain, and syncs custom widget layout settings.
   * **When it connects:** Only when an administrator explicitly enters a License Key and saves settings, or periodically via transient cache to verify license status. If no license key is entered, no requests are made to this service.
   * **Data sent:** Site domain URL, license key, and configured widget styling preferences (color, shape, position).
   * **Terms of Service:** https://accessilens-ai.com/terms
   * **Privacy Policy:** https://accessilens-ai.com/privacy

2. **Google Gemini API (https://ai.google.dev/)**
   * **Purpose:** Powers AI Alt-Text generation for images missing descriptive accessibility text.
   * **When it connects:** Only when an administrator or visitor requests alt-text generation.
   * **Data sent:** Public image URLs (for alt-text generation). Uses the site administrator's own API key stored securely on your server.
   * **Terms of Service:** https://ai.google.dev/terms
   * **Privacy Policy:** https://policies.google.com/privacy

3. **Free Dictionary API (https://api.dictionaryapi.dev/)**
   * **Purpose:** Provides instant word definitions in the accessibility toolbar reading dictionary tool.
   * **When it connects:** Only when a visitor enters a word in the dictionary search tool.
   * **Data sent:** The selected word query (no personally identifiable data is sent).
   * **Terms of Service & Privacy:** https://dictionaryapi.dev/

== Source Code ==

The JavaScript widget included in this plugin (`accessilens.js`) is compiled from TypeScript and React sources for performance. In accordance with the GNU General Public License (GPL) and WordPress.org guidelines, the complete, unminified source code and build instructions are publicly available at:

https://github.com/anshumanmaini/accessilens-ai

To build the widget from source:
1. Clone the repository: `git clone https://github.com/anshumanmaini/accessilens-ai.git`
2. Install dependencies: `npm install`
3. Build the bundle: `npm run build`

== Installation ==

1. Upload the `accessilens-ai` folder to the `/wp-content/plugins/` directory, or install it via the WordPress Plugins menu (**Plugins -> Add New**).
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Go to **Settings -> AccessiLens AI** in your WordPress admin menu.
4. (Optional) Enter your free **AccessiLens License Key** from [accessilens-ai.com/portal](https://accessilens-ai.com/portal) to unlock portal analytics and domain tracking.
5. (Optional) Enter your **Google Gemini API Key** from [Google AI Studio](https://ai.google.dev/) to enable AI Alt-Text generation.
6. Customize your widget color, icon, position, and default language.
7. Click **Save Changes** — the accessibility widget will appear on your live site immediately.

== Frequently Asked Questions ==

= Is AccessiLens free to use? =
Yes. The core accessibility toolbar features (contrast, font resizing, dyslexia fonts, reading mask, focus outlines, dictionary) work completely free. Free license keys with monthly AI quotas are available at [accessilens-ai.com](https://accessilens-ai.com).

= Does this plugin guarantee full ADA / WCAG compliance? =
AccessiLens provides tools that significantly improve accessibility and help address many common WCAG 2.1 AA success criteria. However, no automated widget alone can guarantee 100% legal compliance. We recommend using AccessiLens as part of a comprehensive accessibility strategy.

= Where is my Google Gemini API key stored? =
Your Google Gemini API key is stored securely in your WordPress database options table. It is never exposed in the HTML source code or sent to frontend visitors. All requests pass through an internal WordPress REST API proxy with strict nonce validation.

= Can I customize the look of the floating button? =
Yes. You can customize the widget icon (Person, Universal Access, Wheelchair, Eye, Sparkles), floating position (6 positions), brand accent color, and button shape (round, squircle, square) from the plugin settings page.

= Does it work with page builders (Elementor, Divi, Gutenberg)? =
Yes. AccessiLens works across all WordPress themes and major page builders.

== Screenshots ==

1. The AccessiLens floating accessibility widget on a live site.
2. The expanded accessibility toolbar with profile presets and visual controls.
3. Plugin settings page in the WordPress admin dashboard with live widget customizer preview.

== Changelog ==

= 1.8.252 =
* Fix: Fully compliant with WordPress.org guidelines.
* Fix: Enqueued all admin CSS and JS via `admin_enqueue_scripts` using external files.
* Fix: Removed arbitrary CSS overrides and AI Stylist code execution in compliance with WordPress standards.
* Fix: Replaced all remote font CDN links with locally bundled OpenDyslexic font files.
* Fix: Guaranteed zero telemetry or external HTTP requests without explicit license key consent.
* Added: Public source code repository link and build instructions.
* Added: Third-party service documentation for Dictionary API.

= 1.8.249 =
* Fixed: Removed license key exposure from frontend HTML source.
* Added: Multi-language toolbar UI support (English, Spanish, French, German, Italian, Portuguese, Arabic).
* Improved: Neural Text-to-Speech audio preview and voice selector in admin settings.
* Improved: Domain firewall verification caching for optimal page load speed.
* Security: Hardened REST API proxy permissions and input sanitization.

= 1.0.0 =
* Initial public release.

== Upgrade Notice ==

= 1.8.252 =
Compliance, security, and performance update. All users are strongly encouraged to upgrade.
