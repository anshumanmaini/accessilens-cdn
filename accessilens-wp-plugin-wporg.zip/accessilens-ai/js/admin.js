/**
 * AccessiLens AI - Admin JavaScript
 * Enqueued via admin_enqueue_scripts (complying with WordPress.org guidelines)
 */

document.addEventListener('DOMContentLoaded', function() {
    // 1. Live Preview Widget Updater
    const iconSVGs = {
        person: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg>',
        accessible: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z"/></svg>',
        wheelchair: '<svg viewBox="0 0 24 24"><circle cx="10" cy="4" r="2"/><path d="M10 6v5h5l2.5 6"/><circle cx="8.5" cy="17.5" r="3.5"/><path d="M15 17.5h4"/></svg>',
        eye: '<svg viewBox="0 0 24 24"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>',
        clean: '<svg viewBox="0 0 24 24"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>'
    };

    const fab = document.getElementById('al-preview-fab');
    const colorInput = document.getElementById('accessilens_icon_color');
    const colorHex = document.getElementById('accessilens_color_hex');
    const posSelect = document.getElementById('accessilens_icon_position');
    const shapeSelect = document.getElementById('accessilens_icon_shape');
    const iconHidden = document.getElementById('accessilens_icon_type');
    const iconBtns = document.querySelectorAll('.al-icon-btn[data-icon]');

    function updatePreview() {
        if (!fab || !colorInput || !posSelect || !shapeSelect || !iconHidden) return;

        const color = colorInput.value;
        const pos = posSelect.value;
        const shape = shapeSelect.value;
        const icon = iconHidden.value;

        // Color
        fab.style.backgroundColor = color;

        // Shape
        if (shape === 'round') { 
            fab.style.borderRadius = '9999px'; 
            fab.style.width = '56px'; 
            fab.style.padding = '0'; 
        } else if (shape === 'rounded') { 
            fab.style.borderRadius = '20px'; 
            fab.style.width = '56px'; 
            fab.style.padding = '0'; 
        } else if (shape === 'square') { 
            fab.style.borderRadius = '0'; 
            fab.style.width = '56px'; 
            fab.style.padding = '0'; 
        }

        // Position
        fab.style.top = fab.style.bottom = fab.style.left = fab.style.right = 'auto';
        fab.style.transform = 'none';

        if (pos === 'bottom-right') { fab.style.bottom = '16px'; fab.style.right = '16px'; }
        else if (pos === 'bottom-left') { fab.style.bottom = '16px'; fab.style.left = '16px'; }
        else if (pos === 'top-right') { fab.style.top = '16px'; fab.style.right = '16px'; }
        else if (pos === 'top-left') { fab.style.top = '16px'; fab.style.left = '16px'; }
        else if (pos === 'center-left') { fab.style.top = '50%'; fab.style.left = '16px'; fab.style.transform = 'translateY(-50%)'; }
        else if (pos === 'center-right') { fab.style.top = '50%'; fab.style.right = '16px'; fab.style.transform = 'translateY(-50%)'; }

        // Icon
        fab.innerHTML = iconSVGs[icon] || iconSVGs.person;
    }

    if (colorInput && colorHex) {
        colorInput.addEventListener('input', function() {
            colorHex.value = this.value;
            updatePreview();
        });
        colorHex.addEventListener('input', function() {
            if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                colorInput.value = this.value;
                updatePreview();
            }
        });
    }

    if (posSelect) posSelect.addEventListener('change', updatePreview);
    if (shapeSelect) shapeSelect.addEventListener('change', updatePreview);

    iconBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            iconBtns.forEach(function(b) { b.classList.remove('active'); });
            this.classList.add('active');
            if (iconHidden) iconHidden.value = this.dataset.icon;
            updatePreview();
        });
    });

    updatePreview();

    // 2. TTS Voice Audio Preview Player
    const playBtn = document.getElementById('al-play-voice-btn');
    const voiceSelect = document.getElementById('accessilens_tts_voice');
    let activeAudio = null;

    if (playBtn && voiceSelect) {
        playBtn.addEventListener('click', function() {
            if (activeAudio) {
                activeAudio.pause();
                activeAudio = null;
                playBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="margin-right: 6px;"><path d="M8 5v14l11-7z"/></svg> Preview';
                return;
            }

            const voiceValue = voiceSelect.value;
            const previewText = "Hi there! This is a preview of how your premium read aloud neural voice will sound.";
            const portalUrl = (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
                ? 'http://localhost:3000'
                : 'https://accessilens-ai.com';
            const url = portalUrl + '/api/widget/tts?text=' + encodeURIComponent(previewText) + '&voice=' + encodeURIComponent(voiceValue);

            playBtn.innerHTML = '<span style="display:flex; align-items:center; gap:6px;">⌛ Loading...</span>';
            playBtn.disabled = true;

            const audio = new Audio(url);
            activeAudio = audio;

            audio.oncanplaythrough = function() {
                playBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="margin-right: 6px;"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg> Stop';
                playBtn.disabled = false;
                audio.play().catch(function(err) {
                    console.error(err);
                });
            };

            audio.onended = function() {
                playBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="margin-right: 6px;"><path d="M8 5v14l11-7z"/></svg> Preview';
                activeAudio = null;
            };

            audio.onerror = function() {
                alert('Failed to load preview. Please try again.');
                playBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="margin-right: 6px;"><path d="M8 5v14l11-7z"/></svg> Preview';
                playBtn.disabled = false;
                activeAudio = null;
            };
        });
    }
});
